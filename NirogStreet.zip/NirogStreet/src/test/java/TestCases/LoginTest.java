package TestCases;

import org.testng.annotations.Test;

import Pages.BaseTest;
import Pages.LoginPage;

public class LoginTest extends BaseTest{
  @Test
  public void f() throws InterruptedException {
	  LoginPage obj = new LoginPage();
	  obj.login();
	  
  }
}
