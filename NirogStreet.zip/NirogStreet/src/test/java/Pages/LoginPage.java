package Pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;


public class LoginPage extends BaseTest{
	Properties pro;
//	public WebDriver driver;
	
//	
//	public LoginPage() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.get("https://stg1web.1veda.in/");
//		driver.manage().window().maximize();
////		File src = new File("./Configurations/NirogstreetLocator.properties");
////		try {
////			FileInputStream fis = new FileInputStream(src);
////			pro = new Properties();
////			pro.load(fis);
////		}
////		catch(Exception e) {
////			System.out.println("Not able to load file "+e.getMessage());
////		}
//	}
//	
	public void login() throws InterruptedException {
		Thread.sleep(5000);
		System.out.println(this.driver.getTitle());
		this.driver.findElement(By.xpath("//button[@data-automation='login-signup-button']")).click();
	}
}
