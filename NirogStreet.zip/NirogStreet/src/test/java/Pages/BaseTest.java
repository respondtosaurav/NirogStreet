package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Utilities.BrowserFactory;
import Utilities.ConfigDataProvider;

public class BaseTest {
	public WebDriver driver;
	public ConfigDataProvider config;
	
	@BeforeClass
	public void Setup() {
		//driver = BrowserFactory.StartApp(driver,config.getBrowser(),config.getUrl());
		driver = new ChromeDriver();
		driver.get("https://stg1web.1veda.in/");
		driver.manage().window().maximize();
		System.out.println("In base class");
	}
	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
